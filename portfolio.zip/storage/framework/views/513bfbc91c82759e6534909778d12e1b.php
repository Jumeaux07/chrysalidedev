<div>
    <nav class="navbar">
        <div class="row justify-content-end rest">
            <div class="col-lg-8 rest">

                <!-- navbar links -->
                <ul class="navbar-nav main-bg d-flex justify-content-end">
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="0"><span>Accueil</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="1"><span>Services</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="2"><span>A propos</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="3"><span>Portfolio</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="4"><span>Facturation</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="5"><span>Contact</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#0" data-scroll-nav="6"><span>Blog</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<?php /**PATH D:\ChrysalideDev\projets\web\portfolio\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>