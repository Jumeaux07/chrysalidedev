<?php

namespace App\Livewire;

use Livewire\Component;

class Temoignage extends Component
{
    public function render()
    {
        return view('livewire.temoignage');
    }
}
