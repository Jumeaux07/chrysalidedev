<?php

namespace App\Livewire;

use Livewire\Component;

class Portfolio extends Component
{
    public function render()
    {
        return view('livewire.portfolio');
    }
}
