<?php

namespace App\Livewire;

use Livewire\Component;

class Prix extends Component
{
    public function render()
    {
        return view('livewire.prix');
    }
}
