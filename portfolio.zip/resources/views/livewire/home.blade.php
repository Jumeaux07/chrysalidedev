<div>
    <livewire:intro/>
    <livewire:navbar/>

    <section class="in-box">
        <livewire:service/>
        <livewire:competence/>
        <livewire:portfolio/>
        <livewire:temoignage/>
        <livewire:prix/>
        <livewire:contact/>
        <livewire:blogextrait/>
    </section>
</div>
